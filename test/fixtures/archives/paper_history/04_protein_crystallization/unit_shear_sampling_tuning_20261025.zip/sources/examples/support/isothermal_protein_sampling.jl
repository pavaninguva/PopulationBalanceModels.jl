module IsothermalProteinSampling
using PopulationBalanceModels, ForwardDiff, LinearAlgebra

export bounded_rate_coordinates, expected_information_tuning

"""
An invertible shear of the declared inference coordinates. Keep logit(logAJ)
and logit(g), centre log(gamma) on a smooth constant-initial-rate curve, and
use initial log growth for the growth pair. This avoids the hard curved wall
that a direct logJ/loggamma map creates at the uniform logAJ prior boundary.
The inverse Jacobian is triangular with unit determinant. Priors and their
physical-to-inference Jacobians remain entirely in the EstimationProblem.
"""
function bounded_rate_coordinates(case,problem,reference)
    names=[s.name for s in problem.parameters]
    names[1:4]==[:logAJ,:gamma,:AG,:g] && length(names) in (4,5) ||
        throw(ArgumentError("this case's shear requires logAJ, gamma, AG, g, and optional GRD"))
    a=problem.parameters[1].transform;b=problem.parameters[4].transform
    a isa LogitTransform && b isa LogitTransform ||
        throw(ArgumentError("bounded nucleation/growth exponents require their declared logit coordinates"))
    all(problem.parameters[i].transform isa LogTransform &&
        problem.parameters[i].transform.scale==1 for i in (2,3)) ||
        throw(ArgumentError("gamma and AG require the case's unit-scale logarithmic coordinates"))
    p=physical_parameters(problem,reference,:batch)
    S=case.C0/p.cstar
    logS2=log(S)^2;logexcess=log(S-1)
    logK=log(case.barrier(1.0))
    jref=p.logAJ-case.barrier(p.gamma)/logS2
    sigmoid(v)=v>=0 ? inv(1+exp(-v)) : exp(v)/(1+exp(v))
    A(v)=a.lower+(a.upper-a.lower)*sigmoid(v)
    exponent(v)=b.lower+(b.upper-b.lower)*sigmoid(v)
    softplus(v)=v>0 ? v+log1p(exp(-v)) : log1p(exp(v))
    centre(v)=(log(softplus(A(v)-jref))+log(logS2)-logK)/3
    function to_sampler(z)
        y=copy(z)
        y[2]-=centre(z[1])
        y[3]+=log(.001)+exponent(z[4])*logexcess
        y
    end
    function from_sampler(y)
        z=copy(y)
        z[2]+=centre(y[1])
        z[3]-=log(.001)+exponent(y[4])*logexcess
        z
    end
    (;to_sampler,from_sampler,logabsdetjac=y->zero(eltype(y)),
      label=:CNT_bounded_reference_rates)
end

"""Gaussian expected information plus actual prior curvature, for tuning only.
This omits residual curvature and is not a verified posterior covariance or
Laplace approximation. A nonpositive matrix fails; no diagonal ridge is added.
"""
function expected_information_tuning(problem,z,map)
    y=map.to_sampler(z)
    J=ForwardDiff.jacobian(v->vcat(vec.(only(predictions(problem,map.from_sampler(v))))...),y)
    W=copy(J);offset=0
    for measurement in only(problem.experiments).measurements
        sigma=measurement.likelihood.sigma
        sigma isa Number || sigma isa AbstractArray ||
            throw(ArgumentError("this case's tuning expects fixed Gaussian standard deviations"))
        rows=offset+1:offset+length(measurement.data)
        W[rows,:]./=sigma isa Number ? sigma : vec(sigma)
        offset+=length(measurement.data)
    end
    prior=-ForwardDiff.hessian(v->logprior(problem,map.from_sampler(v))+map.logabsdetjac(v),y)
    information=Symmetric(W'*W+prior)
    factor=cholesky(information)
    covariance=Matrix(Symmetric(factor\Matrix{Float64}(I,length(z),length(z))))
    (;covariance,information=Matrix(information),condition_number=cond(information),
      interpretation="Gaussian expected information plus prior curvature; sampler tuning only, not Laplace")
end
end
