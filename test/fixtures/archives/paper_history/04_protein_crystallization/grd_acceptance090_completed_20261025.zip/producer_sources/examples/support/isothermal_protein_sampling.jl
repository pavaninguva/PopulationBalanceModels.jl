module IsothermalProteinSampling
using PopulationBalanceModels, ForwardDiff, LinearAlgebra

export bounded_rate_coordinates, expected_information_tuning, curvature_tuning

"""
Bound-preserving initial-rate coordinates for the declared CNT law.
Keep logit(logAJ). Let b = B(gamma)/log(S0)^2 and v = inverse_softplus(b).
The second coordinate is v-logAJ, approximately minus the initial log rate
when b is large. The positive barrier b=softplus(y2+logAJ) avoids a curved
hard prior wall and the changing widths of a log-gamma shear.

The inverse-map determinant is sigmoid(v)/(3*softplus(v)); it is included
once by the package sampler. This is a coordinate transformation, not a
changed prior or a physical approximation. The small exponential corrections
omitted below -36 are below Float64 relative precision.
"""
function bounded_rate_coordinates(case,problem,reference)
    names=[s.name for s in problem.parameters]
    length(names) in (4,5) && names[1:4]==[:logAJ,:gamma,:AG,:g] ||
        throw(ArgumentError("these case coordinates require logAJ, gamma, AG, g, and optional GRD"))
    a=problem.parameters[1].transform;b=problem.parameters[4].transform
    a isa LogitTransform && b isa LogitTransform ||
        throw(ArgumentError("logAJ and g require their declared logit coordinates"))
    all(problem.parameters[i].transform isa LogTransform &&
        problem.parameters[i].transform.scale==1 for i in (2,3)) ||
        throw(ArgumentError("gamma and AG require the case's unit-scale logarithmic coordinates"))
    p=physical_parameters(problem,reference,:batch)
    logS2=log(case.C0/p.cstar)^2;logexcess=log(case.C0/p.cstar-1)
    logK=log(case.barrier(1.0))
    sigmoid(v)=v>=0 ? inv(1+exp(-v)) : exp(v)/(1+exp(v))
    A(v)=a.lower+(a.upper-a.lower)*sigmoid(v)
    exponent(v)=b.lower+(b.upper-b.lower)*sigmoid(v)
    softplus(v)=v>0 ? v+log1p(exp(-v)) : log1p(exp(v))
    logsoftplus(v)=v < -36 ? v : log(softplus(v))
    function to_sampler(z)
        lb=logK+3z[2]-log(logS2)
        v=if lb < -36
            lb
        else
            barrier=exp(lb)
            isfinite(barrier) || throw(NumericalFailure("CNT sampling barrier overflow"))
            barrier+log(-expm1(-barrier))
        end
        y=copy(z);y[2]=v-A(z[1])
        y[3]+=log(.001)+exponent(z[4])*logexcess
        y
    end
    function from_sampler(y)
        v=y[2]+A(y[1])
        z=copy(y);z[2]=(logsoftplus(v)+log(logS2)-logK)/3
        z[3]-=log(.001)+exponent(y[4])*logexcess
        z
    end
    logabsdetjac(y)=let v=y[2]+A(y[1])
        -softplus(-v)-log(3)-logsoftplus(v)
    end
    (;to_sampler,from_sampler,logabsdetjac,label=:CNT_soft_barrier_rates)
end

"""Gaussian expected information plus actual prior curvature, for tuning only.
This omits residual curvature and is not a verified posterior covariance or
Laplace approximation. A nonpositive matrix fails; no diagonal ridge is added.
"""
function expected_information_tuning(problem,z,map)
    y=map.to_sampler(z)
    J=ForwardDiff.jacobian(v->vcat(vec.(only(predictions(problem,map.from_sampler(v))))...),y)
    W=copy(J);offset=0
    for measurement in only(problem.experiments).measurements
        sigma=measurement.likelihood.sigma
        sigma isa Number || sigma isa AbstractArray ||
            throw(ArgumentError("this case's tuning expects fixed Gaussian standard deviations"))
        rows=offset+1:offset+length(measurement.data)
        W[rows,:]./=sigma isa Number ? sigma : vec(sigma)
        offset+=length(measurement.data)
    end
    prior=-ForwardDiff.hessian(v->logprior(problem,map.from_sampler(v))+map.logabsdetjac(v),y)
    information=Symmetric(W'*W+prior)
    factor=cholesky(information)
    covariance=Matrix(Symmetric(factor\Matrix{Float64}(I,length(z),length(z))))
    (;covariance,information=Matrix(information),condition_number=cond(information),
      interpretation="Gaussian expected information plus prior curvature; sampler tuning only, not Laplace")
end

"""Initial sampler metric from local observed curvature in inference coordinates.
The inverse curvature is pushed into sampler coordinates by the local Jacobian.
This is tuning only: it is not a verified Laplace approximation, and no intervals
are obtained from this matrix. Nonfinite or nonpositive curvature fails without
a ridge. Distinct calibration basins may initialize distinct chain metrics.
"""
function curvature_tuning(problem,z,map)
    H=ForwardDiff.hessian(v->-logposterior(problem,v),z)
    all(isfinite,H) || throw(ArgumentError("nonfinite local posterior curvature; cannot initialize this sampler metric"))
    factor=cholesky(Symmetric(H))
    inverse=factor\Matrix{Float64}(I,length(z),length(z))
    J=ForwardDiff.jacobian(map.to_sampler,z)
    covariance=Matrix(Symmetric(J*inverse*J'))
    cholesky(Symmetric(covariance))
    (;covariance,information=Matrix(Symmetric(H)),condition_number=cond(covariance),
      interpretation="Local inference-coordinate observed curvature, transformed for sampler tuning only; not a verified Laplace covariance")
end
end
