# Thin entry point: one shared model/likelihood, optional verified checkpoints.
module ProteinCaseReproduction
using PopulationBalanceModels, Optim, JSON3, SHA, Dates, LinearAlgebra, Statistics, Random, TOML, Pkg, AdvancedHMC, MCMCDiagnosticTools, Serialization
include(joinpath(@__DIR__,"..","..","..","examples","isothermal_protein_crystallization.jl"))
using .IsothermalProteinCrystallization
const C=IsothermalProteinCrystallization
const ROOT=realpath(joinpath(@__DIR__,"..","..",".."))
include("report.jl")
const DRIVER_HASHES=Dict(f=>hashfile(joinpath(@__DIR__,f)) for f in ("run.jl","report.jl","config.toml"))

function main(args=ARGS)
    if !isempty(args) && first(args)=="--chain-worker"
        input=deserialize(args[2]);chain=parse(Int,args[3])
        post=sample_chain(input.model,input.config,input.z,input.starts[chain],input.covariance,chain)
        serialize(input.paths[chain],post)
        return
    end
    allowed=("--model","--bins","--warmup","--samples","--chains","--seed","--predictive-draws","--maxiters","--target-acceptance")
    flags=("--smoke","--map","--full","--sample","--data-only","--verify","--force")
    all(a->a in flags || first(split(a,'=')) in allowed,args) || error("Unknown flag; see README.md")
    option(name,default)=let found=filter(a->startswith(a,name*"="),args)
        isempty(found) ? default : split(last(found),'=';limit=2)[2]
    end
    smoke="--smoke" in args
    config=TOML.parsefile(joinpath(@__DIR__,"config.toml"))[smoke ? "smoke" : "production"]
    for (flag,key) in (("--bins","bins"),("--warmup","warmup"),("--samples","samples"),
                       ("--chains","chains"),("--seed","seed"),("--predictive-draws","predictive_draws"),("--maxiters","maxiters"))
        haskey(config,key) && (config[key]=parse(Int,option(flag,string(config[key]))))
    end
    haskey(config,"target_acceptance") &&
        (config["target_acceptance"]=parse(Float64,option("--target-acceptance",string(config["target_acceptance"]))))
    model=option("--model","both")
    model in ("cnt","cnt_grd","both") || error("--model=cnt, cnt_grd or both")
    mode=smoke ? "smoke" : "production"
    root=joinpath(ROOT,"paper","results","04_protein_crystallization",mode)
    normpath(dirname(dirname(pathof(PopulationBalanceModels))))==ROOT || error("develop the checkout with paper/setup.jl")
    export_data(root)
    "--data-only" in args && return
    for name in (model=="both" ? (:cnt,:cnt_grd) : (Symbol(model),))
        active=copy(config)
        if !any(a->startswith(a,"--bins="),args) && haskey(config,"bins_by_model")
            active["bins"]=config["bins_by_model"][string(name)]
        end
        if haskey(config,"sampler_by_model") && haskey(config["sampler_by_model"],string(name))
            for (key,value) in config["sampler_by_model"][string(name)]
                flag="--"*replace(key,'_'=>'-')*"="
                any(a->startswith(a,flag),args) || (active[key]=value)
            end
        end
        if "--verify" in args
            smoke && error("--verify checks completed production posteriors; use --smoke for forward checks")
            verify_saved_target(root,name,active)
        else
            execute_model(root,name,active;smoke,
                sample=("--full" in args || "--sample" in args),force="--force" in args)
        end
    end
end
end
if abspath(PROGRAM_FILE)==@__FILE__
    ProteinCaseReproduction.main()
end
