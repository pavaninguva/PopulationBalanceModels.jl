include("/mnt/c/Users/Pavan/Projects/PopulationBalanceModels.jl/paper/case_studies/04_protein_crystallization/run.jl")
const R=ProteinCaseReproduction
using PopulationBalanceModels,ForwardDiff,LinearAlgebra,Distributions,Random
cfg=R.TOML.parsefile(joinpath(R.ROOT,"paper/case_studies/04_protein_crystallization/config.toml"))["production"]
merge!(cfg,cfg["sampler_by_model"]["cnt_grd"]);cfg["bins"]=100
p=R.make_estimation(cfg,:cnt_grd)
z=Float64.(R.readjson(joinpath(R.ROOT,"paper/results/04_protein_crystallization/production/cnt_grd/map.json")).z)
base=R.sampling_map(p,z,cfg);normal=Normal()
sigmoid(v)=v>=0 ? inv(1+exp(-v)) : exp(v)/(1+exp(v))
probit(z)=z>0 ? -quantile(normal,sigmoid(-z)) : quantile(normal,sigmoid(z))
logitnormal(u)=logcdf(normal,u)-logccdf(normal,u)
function frombase(y)
 u=copy(y);u[1]=probit(y[1]);u[4]=probit(y[4]);u
end
function tobase(u)
 y=copy(u);y[1]=logitnormal(u[1]);y[4]=logitnormal(u[4]);y
end
function lj(u)
 base.logabsdetjac(tobase(u))+sum(logpdf(normal,u[i])-logcdf(normal,u[i])-logccdf(normal,u[i]) for i in (1,4))
end
map=(to_sampler=z->frombase(base.to_sampler(z)),from_sampler=u->base.from_sampler(tobase(u)),logabsdetjac=lj,label=:CNT_normal_bound_rates)
for q in (z,z+[.7,-.02,.01,.9,.08])
 println(check_sampling_map(p,map,q));flush(stdout)
end
tuning=R.IsothermalProteinSampling.curvature_tuning(p,z,map)
println("pilot covariance condition ",tuning.condition_number);flush(stdout)
start=map.from_sampler(map.to_sampler(z)+.3cholesky(Symmetric(tuning.covariance)).L*randn(MersenneTwister(17292),5))
@time post=sample_posterior(p;initial=z,starts=[start],sampling_map=map,metric=:dense,
 initial_covariance=tuning.covariance,warmup=200,samples=100,chains=1,seed=17292,
 target_acceptance=.995,max_depth=11,verbose=true)
d=diagnostics(post)
R.serialize("/tmp/protein-normal-bound-pilot.bin",post)
R.json("/tmp/protein-normal-bound-pilot.json",(per_chain=d.per_chain,failed_evaluations=d.failed_evaluations,failure_messages=d.failure_messages,elapsed_seconds=d.elapsed_seconds))
println("PILOT ONLY: ",d.per_chain);flush(stdout)
